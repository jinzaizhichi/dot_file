# Reporting security issues

To report a security issue, send your report to less@greenwoodsoftware.com.
